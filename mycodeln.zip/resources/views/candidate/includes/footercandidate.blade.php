<!-- footer content -->
<footer>
    <div class="pull-right">
        <p>©2016 All Rights Reserved. Code\n! all rights</p>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>

{{--<!-- jQuery -->--}}
{{--<script src="js2/jquery.min.js"></script>--}}
{{--<!-- Bootstrap -->--}}
{{--<script src="js2/bootstrap.min.js"></script>--}}
{{--<!-- FastClick -->--}}
{{--<script src="js2/fastclick.js"></script>--}}
{{--<!-- NProgress -->--}}
{{--<script src="js2/nprogress.js"></script>--}}
{{--<!-- Chart.js -->--}}
{{--<script src="js2/Chart.min.js"></script>--}}
{{--<!-- gauge.js -->--}}
{{--<script src="js2/gauge.min.js"></script>--}}
{{--<!-- bootstrap-progressbar -->--}}
{{--<script src="js2/bootstrap-progressbar.min.js"></script>--}}
{{--<!-- iCheck -->--}}
{{--<script src="js2/icheck.min.js"></script>--}}
{{--<!-- Skycons -->--}}
{{--<script src="js2/skycons.js"></script>--}}
{{--<!-- Flot -->--}}
{{--<script src="js2/jquery.flot.js"></script>--}}
{{--<script src="js2/jquery.flot.pie.js"></script>--}}
{{--<script src="js2/jquery.flot.time.js"></script>--}}
{{--<script src="js2/jquery.flot.stack.js"></script>--}}
{{--<script src="js2/jquery.flot.resize.js"></script>--}}
{{--<!-- Flot plugins -->--}}
{{--<script src="js2/jquery.flot.orderBars.js"></script>--}}
{{--<script src="js2/jquery.flot.spline.min.js"></script>--}}
{{--<script src="js2/curvedLines.js"></script>--}}
{{--<!-- DateJS -->--}}
{{--<script src="js2/date.js"></script>--}}
{{--<!-- JQVMap -->--}}
{{--<script src="js2/jquery.vmap.js"></script>--}}
{{--<script src="js2/jquery.vmap.world.js"></script>--}}
{{--<script src="js2/jquery.vmap.sampledata.js"></script>--}}
{{--<!-- bootstrap-daterangepicker -->--}}
{{--<script src="js2/moment.js"></script>--}}
{{--<script src="js2/daterangepicker.js"></script>--}}
{{--<script src="js2/ion.rangeSlider.min.js"></script>--}}

{{--<!-- Custom Theme Scripts -->--}}
{{--<script src="js2/custom.js"></script>--}}
{{--<script  src="js2/index.js"></script>--}}

</body>
</html>