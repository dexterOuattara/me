<br />

<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">


            <li><a href="/calltoapply"><i class="fa fa-send"></i> CALL TO APPLY <span class="label label-success pull-right">3</span></a></li>
            <li><a href="/pendingproject"><i class="fa fa-code"></i>PENDING PROJECT <span class="label label-success pull-right">1</span></a></li>
            <li><a href="/meeting"><i class="fa fa-user"></i> MY MEETING <span class="label label-success pull-right">1</span></a></li>
            <li><a href="/myresume"><i class="fa fa-file"></i> MY RESUME <span class="label label-success pull-right">20 % complete</span></a></li>

        </ul>
    </div>


</div>

</div>
</div>

<!-- top navigation -->
<div class="top_nav">
    <div class="nav_menu">
        <nav>

            <ul class="nav navbar-nav navbar-left">

            </ul>
        </nav>
    </div>
</div>
<!-- /top navigation -->