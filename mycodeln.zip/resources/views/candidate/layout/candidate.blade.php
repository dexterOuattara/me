@include('includes.headcandidate')
@include('includes.headercandidate')
@yield('content')
@include('includes.footercandidate')


