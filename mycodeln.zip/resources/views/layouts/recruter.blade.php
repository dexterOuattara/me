    @include('includes.headrecruter')
    @include('includes.headerecruter')
    @yield('content')
    @include('includes.footercandidate')


