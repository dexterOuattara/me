<div id="back-top" class="back-top">
    <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a>
</div>
<!--/Back-to-top-->


<!-- Scripts -->
{{--<script src="assets/js/jquery.min.js"></script>--}}
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/interface.js"></script>
<!--<script src="assets/js/languageanimation.js"></script>-->
<!--Switcher-->
<script src="assets/js/jquery.validate.min.js"></script>
<!--Carousel-JS-->
<script src="assets/js/owl.carousel.min.js"></script>
<!-- prettyPhoto-->
<script src="assets/js/jquery.prettyPhoto.js"></script>
<script>
    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').focus()
    })
</script>