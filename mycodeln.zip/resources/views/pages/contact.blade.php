@extends('layouts.default')
@section('content')
    <h1>I am the contact page</h1>
@stop