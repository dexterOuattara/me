@extends('layouts.sidebar')
@section('content')
    i am the projects page
@stop